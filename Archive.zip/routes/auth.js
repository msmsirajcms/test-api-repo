const express = require("express");
const router = express.Router();
const authController = require("../controllers/authController");

router.post('/', (req, res) => {
    try {
        const login = authController.login({username,password})
        res.sendStatus(200)
        return login;
      
    } catch (error) {
        next(error)
    }
});

module.exports = router;
