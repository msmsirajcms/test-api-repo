function errorHandler(err, req, res, next) {
  console.error("Error:", err); // Log the error for debugging purposes

  const status = err.response?.status || err.status || 500;
  const message = err.response?.data || err.message || "An error occurred";

  // Define error categories based on status code
  const errorCategory = status >= 500
    ? "Server error"
    : status >= 400
    ? "Client error"
    : status >= 300
    ? "Redirection error"
    : "Unexpected error";

  // Customize the error response
  res.status(status).json({
    error: errorCategory,
    details: message,
  });
}

module.exports = errorHandler;
