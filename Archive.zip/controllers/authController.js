const jwt = require("jsonwebtoken");
const authService = require("../services/authService");

// Login endpoint
async function login(req, res, next) {
  const { email, password } = req.body;

  try {
    const login = await authService.login(email, password);
    res.json(login);
  } catch (error) {
    next(error);
  }
}

// Verify token middleware
function verifyToken(req, res, next) {
  const bearerToken = req.headers.authorization;

  // Check if the bearer token exists
  if (!bearerToken) {
    return next(createUnauthorizedError());
  }

  const token = bearerToken.split(' ')[1];


  if (!token) {
    return next(createUnauthorizedError());
  }

  try {

    const decoded = jwt.decode(token);

    if (!decoded) {
      return next(createUnauthorizedError());
    }

    req.user = decoded;
    next();
  } catch (error) {
    console.error('Error:', error);
    return next(createUnauthorizedError());
  }
}

function createUnauthorizedError() {
  const error = new Error('Unauthorized');
  error.status = 401;
  return error;
}

module.exports = {
  login,
  verifyToken,
};
