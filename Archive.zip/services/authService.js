const axios = require("axios");

const apiClient = axios.create({
  baseURL: process.env.BASE_URL_V1, 
  headers: {
    'Content-Type': 'application/json'
  }
});

const login = async (email, password) => {
  try {

    const { data: loginData } = await apiClient.post('/login', { email, password });
    const token = loginData?.requestToken;

    const authHeaders = {
      headers: { Authorization: `Bearer ${token}` }
    };


    const { data: whoAmIData } = await apiClient.post('/whoAmI', {}, authHeaders);

    const { idtenant, name, iddefault_group } = whoAmIData.tenant
    const { iduser, first_name, last_name, username} = whoAmIData
    return {
      token,
      profile:{
        tenant: {
            id:idtenant,
            name,
            iddefault_group
        },
        user: {
          id:iduser,
          first_name,
          last_name,
          username
        }
      }
    };

  } catch (error) {
    console.error('Login error:', error.response?.data || error.message);
    throw error;
  }
};

module.exports = {
  login,
};
